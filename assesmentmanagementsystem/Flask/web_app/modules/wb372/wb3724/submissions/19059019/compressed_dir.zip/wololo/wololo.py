""" Test wololo """

def wololo():
    """ Test wololo """
    return "wololo"
