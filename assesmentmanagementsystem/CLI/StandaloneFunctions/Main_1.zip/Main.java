import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    private static final boolean DEBUG = false;

    private static void debugln(String message) {
        if (DEBUG) {
            System.out.println(message);
        }
    }

    public static void processCase(Scanner in, PrintStream out, int caseNum) {
        boolean coms = true;
        LinkedList<Integer> queries = new LinkedList<>();
        int k = in.nextInt();
        int m = in.nextInt();
        int[] weights = new int[k];
        String[] edges = new String[m];
        ArrayList<Integer>[] vertices = new ArrayList[k];

        // Expect Vertices
        for (int i = 0; i < k; i++) {
            vertices[i] = new ArrayList<>();
            weights[i] = in.nextInt();
        }
        // Expect Edges
        for (int i = 0; i < m; i++) {
            int from = in.nextInt() - 1;
            int to = in.nextInt() - 1;

            // for linkedlist
            vertices[from].add(to);
            vertices[to].add(from);

            edges[i] = from + "-" + to;
        }

        while (coms) {
            int command = in.nextInt();
            switch (command) {
            // Delete X-th edge
            case 0:
                int x = in.nextInt();
                String[] coords = edges[x - 1].split("-");
                int to = Integer.parseInt(coords[1]);
                int from = Integer.parseInt(coords[0]);

                // for linkedlist
                vertices[to].remove(Integer.valueOf(from));
                vertices[from].remove(Integer.valueOf(to));

                break;
            // Change Weight of vertex X to Y
            case 1:
                int vertex = in.nextInt();
                int weight = in.nextInt();
                weights[vertex - 1] = weight;
                break;
            // Fetch Weight of Y-th Largest vertex connected to X (illegal = 0)
            case 2:
                int vertex1 = in.nextInt() - 1;
                int index = in.nextInt();
                LinkedList<Integer> connected = new LinkedList<>();
                connected.add(weights[vertex1]);
                for (int i : vertices[vertex1]) {
                    connected.add(weights[i]);
                }

                if (index <= connected.size()) {
                    Collections.sort(connected);
                    queries.add(connected.get(connected.size() - index));
                } else {
                    queries.add(0);
                }
                break;
            // Terminate test case
            case 3:
                coms = false;
                break;
            }
        }
        double sum = 0;
        for (int i : queries) {
            sum += i;
        }
        out.print("" + caseNum + ": ");
        out.printf(Locale.US, "%.6f\n", sum / queries.size());
    }

    public static void process(Scanner in, PrintStream out) {
        int N = in.nextInt();
        for (int i = 1; i <= N; i++) {
            processCase(in, out, i);
        }
    }

    public static void main(String[] argv) {
        process(new Scanner(System.in), System.out);
    }

}